import argparse, os, sys, datetime, glob, importlib, csv
import numpy as np
import time
import torch
import torchvision
import pytorch_lightning as pl
from tqdm import tqdm
from einops import rearrange

from packaging import version
from omegaconf import OmegaConf 
from torch.utils.data import random_split, DataLoader, Dataset, Subset
from functools import partial
from PIL import Image
from patchify import patchify, unpatchify
import pdb

# inria: 2 classes? multiclasses in an image?

# TODO delete rgb_mask, insert in_ch
# consider do everything with torch tensors, in cuda. Measure difference between cpu and gpu
# maybe separate functions for images and masks
def preprocess_data(img, msk, device, mode="RGB", mask_ch = 1, left=0, top=0, size=64, threshold=0.5, transform=torchvision.transforms.ToPILImage()):
    trh = threshold # problems
    right, bottom = left+size, top+size # bottom disturbed by multiple assignments on same line
    shape = (left, top, right, bottom) # shape(None) = (0)

    if type(img) == str:
      image = np.array(Image.open(img).convert(mode))
    else:
      image = transform(img).convert(mode)
      image = np.array(image.crop(shape))

    image = image.astype(np.float32)/255.0
    if len(image.shape)==2: 
      image = image[:,:,None]
    image = image.transpose(2,0,1)
    image = torch.from_numpy(image)


    if type(msk) == str:
      mask_image = Image.open(msk)
    elif msk is None:
        pass
    else:
      mask_image = transform(msk).convert("L")
      mask_image = np.array(mask_image.crop(shape))

    if mask_ch==3:
      mask = np.array(mask_image).astype(np.float32)/255.0 # careful, this command does notreturn error with mask_image=None
      if mask.shape[-1] == 3:
        mask = mask.transpose(2,0,1)
    elif mask_ch==1:
      mask = np.array(mask_image) # what is this L?? related to L in apply_image??
      mask = mask.astype(np.float32)/255.0
      mask = mask[None]
      mask[mask < trh] = 0
      mask[mask >= trh] = 1
      #masked_image = (1*mask) * image + mask*image # mask is only 2-class; how to do it with multiclass? Multiclass inpaint?
    else:
        mask = None
      

    if mask is not None:
        mask = torch.from_numpy(mask)
        batch = {"image": image, "mask": mask}
    else:
        batch = {"image": image}

    for k in batch:
        batch[k] = batch[k].to(device=device)
        batch[k] = batch[k]*2.0-1.0 # be careful
    return batch

def visualize_data(outpath):
    pass


class MyDataset(Dataset):
    def __init__(self, images, masks, size=64, device="cpu", nlabels = 2, rgb_mask=None):
        li, lm = len(images), len(masks)
        assert li==lm, print(f"different lengths {li} {lm}")
        self.length = len(images)
        self.ims, self.masks = images, masks
        self.nlabels = nlabels
        self.size = size
        self.device = device
        self.rgb_mask = rgb_mask
    def __len__(self):
        return self.length
    def __getitem__(self, i):
        #example = dict((k, self.labels[k][i]) for k in self.labels)
        example = dict()
        image, mask = self.ims[i], self.masks[i]
        batch = preprocess_data(image, mask, self.device, size = self.size, rgb_mask = self.rgb_mask) # TODO, very slow

        image,mask = batch["image"][0], batch["mask"][0]
        image, mask = rearrange(image, 'c h w -> h w c'), rearrange(mask, 'c h w -> h w c')


        processed = {"image": image, "mask": mask}
        example["image"] = processed["image"]
        segmentation = processed["mask"]
        example["segmentation"] = segmentation
        return example

class DerivedDataset(MyDataset):
    def __getitem__(self,i):
        batch = super().__getitem__(i)
        #breakpoint()
        batch["segmentation2"] = batch.pop("segmentation")
        #breakpoint()
        return batch

def preprocess():
    pass

def augment():
    pass

def select_class(images, masks, cat=None):
  if cat is None:
    return images, masks
  images = [image for image in images if os.path.split(image)[-1][:3]==cat[:3]]
  masks = [mask for mask in masks if os.path.split(mask)[-1][:3]==cat[:3]]
  return sorted(images), sorted(masks)

def extract_patches(images, masks, h,w, n_patches=1, size=64, rgb_mask=None, ratio=0.4, device="cpu", threshold=0.5):
        ims, ms = [], []
        step = int(ratio*size)
        for i, (im,mask) in enumerate(zip(images,masks)):
          n = 0
          print(f"extracting patches from image {i} in dataset")
          # with this loop we discard the right and bottom extremum of the image
          for left,top in zip(range(0,w,step),range(0,h,step)):
            if left+size >=w or top+size>=h or n>=n_patches:
                break
            batch = preprocess_data(im, mask, device, left=left, top=top, size=size, rgb_mask = rgb_mask, threshold = threshold)
            ims.append(batch["image"]), ms.append(batch["mask"])
            imfile, maskfile = os.path.splitext(im)[0], os.path.splitext(mask)[0]
            imfile, maskfile = imfile + f"_{n}.tif", maskfile + f"{n}.tif"
            n+=1
          print(f"{n} patches extacted")

        return ims, ms

def make_patches(imfiles, device="cpu", in_ch=3, outpath=None, num_patches=1, size=64, ratio=0.5, step=None):
  transform = torchvision.transforms.ToPILImage()
  length = len(imfiles)
  im_patches = torch.zeros((num_patches*(length), size, size, in_ch)).to(device) # originally numpy
  print(f"extracting patches from {in_ch} channels images")
  if step is None:
    step = int((1-ratio)*size)
  for i, imfile in enumerate(imfiles):
    print(f"image {i+1}")
    if in_ch == 3:
      image = np.array(Image.open(imfile).convert("RGB"))
    else:
      image = np.array(Image.open(imfile).convert("L"))[:,:,None] # original: without .convert("L")
    image_patches = patchify(image, (size, size, image.shape[-1]), step) # torch function to patchify everything? Unfold?
    image_patches = torch.from_numpy(image_patches).to(device) # maybe translate all to numpy or all to torch (.astype substitute)
    image_patches = torch.flatten(image_patches, start_dim=0, end_dim=2)
    n_patches = min(num_patches, image_patches.shape[0])
    image_patches = image_patches[:n_patches]
    im_patches[n_patches*i:n_patches*(i+1)]=image_patches
  im_patches = im_patches.to(device, dtype=torch.uint8) # maybe rearrange dims, careful for next rearrange in preprocess_data
  im_patches = rearrange(im_patches, 'b h w c -> b c h w')

  if outpath is None:
    return im_patches

  for idx in range(im_patches.shape[0]):
    img = transform(im_patches[idx]) # careful, im_patches are numpy, not torch.tensor
    outfile = os.path.join(outpath, f"sample_{idx}.tif")
    img.save(outfile)


    

# TODO: load images and masks names directly into dataset  
class InriaDataset(Dataset):
    # would be nice having init working once per all
    def __init__(self, path="data/AerialImageDataset", val_split=0.15, length=0, num_patches=1, patch_overlap=0.5, 
    size=64, device="cpu", nlabels = 2, img_ch=3, mask_ch=1, category = None, threshold=0.5):
        images = sorted(glob.glob(os.path.join(path, "train/images", "*tif")))
        masks = sorted(glob.glob(os.path.join(path, "train/gt", "*tif")))
        li, lm = len(images), len(masks)
        self.h,self.w = 5000,5000
        assert li==lm, print(f"different lengths {li} {lm}")
        self.nlabels, self.num_patches = nlabels, num_patches
        self.size, self.patch_overlap = size, patch_overlap
        self.step = min(int(self.patch_overlap*self.size), int(self.h/self.num_patches))
        self.device = device
        assert img_ch == 1 or img_ch==3, print("image channels must be 1 or 3")
        self.mode = "RGB" if img_ch==3 else "L"
        self.category = category
        self.device, self.threshold = device, threshold
        images, masks = select_class(images, masks, cat=category)
        if length > 0 and length < len(images):
          images, masks = images[:length], masks[:length]

        # few shot learning 
        """
        ims, ms=[],[]
        for i in range(8):
          ims.append(images[0])
          ms.append(masks[0])
        images=ims
        masks=ms"""
        
        
        self.ims, self.masks = make_patches(images, in_ch=img_ch, num_patches = self.num_patches, size=self.size, ratio=patch_overlap), make_patches(masks, num_patches=self.num_patches, in_ch=mask_ch, size=self.size, ratio=patch_overlap) #images, masks
        self.length = len(self.ims) if type(self.ims) is list else self.ims.shape[0]
        self.val_length = int(val_split*self.length) # subtle problem: val_length updated with same length accessed by TRAIN on gpu 0 for gpu 1!!!


    def __len__(self):
        return self.length
    def __getitem__(self, n):
        #example = dict((k, self.labels[k][i]) for k in self.labels)
        example = dict()
        imfile, maskfile = self.ims[n], self.masks[n] #mask gets corrupted during training, but in debuggign is fine!!
        batch = preprocess_data(imfile, maskfile, self.device, mode=self.mode, size=self.size) # image, mask = process() instead of batch=process damn!!
        image,mask = batch["image"], batch["mask"]

        if image.shape[-1]>image.shape[0]:
          image, mask = rearrange(image, 'c h w -> h w c'), rearrange(mask, 'c h w -> h w c')
        
        """
        breakpoint()
        image, mask = patchify(image.cpu().numpy(), (self.size, self.size, image.shape[-1]), self.step), patchify(mask.cpu().numpy(), (self.size, self.size, mask.shape[-1]), self.step)
        image, mask = torch.from_numpy(image).to(self.device), torch.from_numpy(mask).to(self.device)
        image, mask = torch.flatten(image, start_dim=0, end_dim=2), torch.flatten(mask, start_dim=0, end_dim=2)
        n_patches = min(self.n_patches, image.shape[0])
        image, mask = image[:n_patches], mask[:n_patches]
        breakpoint()

        for i in range(n_patches):
          example["image"] = image[i]
          example["segmentation"] = mask[i]
          return example """
        example["image"]=image
        example["segmentation"]=mask
        return example

# must redefine also len?
class trainInriaDataset(InriaDataset):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.val_length>0:
            self.ims, self.masks = self.ims[self.val_length:], self.masks[self.val_length:]

        #self.ims, self.masks = extract_patches(self.ims, self.masks, self.h, self.w, size=self.size, device=self.device, rgb_mask=self.rgb_mask, 
        #threshold=self.threshold, n_patches=self.n_patches) # doubled in tr and val
        self.length = len(self.ims)

    def __getitem__(self,i):
        batch = super().__getitem__(i)
        return batch

class valInriaDataset(InriaDataset):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.val_length>0:
            self.ims, self.masks = self.ims[:self.val_length], self.masks[:self.val_length]

        #self.ims, self.masks = extract_patches(self.ims, self.masks, self.h, self.w, size=self.size, device=self.device, rgb_mask=self.rgb_mask, 
        #threshold=self.threshold, n_patches=self.n_patches) # doubled in tr and val
        self.length = len(self.ims)
    def __getitem__(self,i):
        batch = super().__getitem__(i)
        return batch